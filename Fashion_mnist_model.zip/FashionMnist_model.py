
"""
  --- Nguyen Minh Duc ---
Original file is located at
    https://colab.research.google.com/drive/1rF36ADUuSMA2BCXlr39VDI32v3iE18Eu
"""

import tensorflow as tf
import matplotlib.pyplot as plt
import numpy as np
import cv2

# load dataset
(x_train, y_train), (x_test, y_test)= tf.keras.datasets.fashion_mnist.load_data()
x_train, x_test = x_train / 255.0, x_test / 255.0

# create model
model = tf.keras.models.Sequential([
      tf.keras.layers.Flatten(input_shape = (28,28)),
      tf.keras.layers.Dense(250,activation= 'relu'), 
      tf.keras.layers.Dropout(0.1),
      tf.keras.layers.Dense(150,activation= 'relu'), 
      tf.keras.layers.Dense(10, activation='softmax')                       
])
model.compile(optimizer='adam',
              loss='sparse_categorical_crossentropy',
              metrics=['accuracy'])

# train model
model.fit(x_train, y_train, batch_size = 200, epochs = 10, validation_split= 0.2)

# evaluate test set
model.evaluate(x_test,y_test,verbose=2)

#predict label 
def predict_output(image):
  class_label = ['t-shirt','trouser','pullover','dress','coat','sandal','shirt','sneaker','bag','boot']
  predict = model.predict(image.reshape(1,28,28))
  a = np.argmax(predict[0])
  label = class_label[a]
  return label

#plot function 
def plot_image(image):
  img = image.reshape(28,28)
  plt.imshow (img,cmap=plt.cm.gray_r, interpolation='nearest')
def plot_prediction(image):
  predict = model.predict(image.reshape(1,28,28))
  plt.bar(range(10),predict[0])

# read new image
import cv2
image = cv2.imread('F:\MACHINE LEARNING\AI VN\data\data_fashion_mnist\Test_NewImage\trouser.jpg') # file new image path
image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
image = np.max(image)-image # keep this line if the object lighter than background
image = cv2.resize(image,(28,28))
# show result
plt.figure(figsize= (6,3))
plt.subplot(1,2,1)
plt.title(predict_output(image))
plot_image(image)
plt.subplot(1,2,2)
plot_prediction(image)
plt.show()
