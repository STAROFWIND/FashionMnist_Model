Open code file /FashionMnist_model.py
you can copy the link at the top and paste to your browse
Using Google Colab to build this code
You also run locally on your computer but you have to download dataset and adjust some codeing lines to read your downloaded dataset
